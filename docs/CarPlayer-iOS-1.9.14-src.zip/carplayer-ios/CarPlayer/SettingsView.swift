﻿import SwiftUI
import UIKit
/// 设置页：对齐 activity_settings（res/q3.xml）
struct SettingsView: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var router: Router
    @ObservedObject private var downloader = Downloader.shared

    @State private var showQuality = false
    @State private var showSourceSection = false
    @State private var showMoreSection = false
    @State private var showScriptSheet = false
    @State private var showPlaylistImport = false
    @State private var showQingSheet = false
    @State private var showHelp = false
    @State private var showCrash = false
    @State private var scriptText = ""
    @State private var playlistText = ""
    @State private var qingText = ""
    @State private var busy = false

    private var scriptedSources: [ScriptMeta] { store.scripts }

    var body: some View {
        VStack(spacing: 0) {
            header
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 0) {
                    downloadSection
                    sourceSectionToggle
                    if showSourceSection { sourceSection }
                    importPlaylistRow
                    moreToggle
                    if showMoreSection { moreSection }
                    versionRow
                }
                .padding(.horizontal, 16)
                .padding(.bottom, 28)
            }
        }
        .background(Palette.bg.ignoresSafeArea())
        .confirmationDialog("下载音质", isPresented: $showQuality, titleVisibility: .visible) {
            ForEach(Quality.downloadOptions) { quality in
                Button(quality.display) {
                    store.settings.downloadQuality = quality
                    store.persistAll()
                }
            }
            Button("取消", role: .cancel) {}
        }
        .sheet(isPresented: $showScriptSheet) { scriptImportSheet.presentationDetents([.height(420)]) }
        .sheet(isPresented: $showPlaylistImport) { playlistImportSheet.presentationDetents([.height(340)]) }
        .sheet(isPresented: $showQingSheet) { qingSheet.presentationDetents([.height(400)]) }
        .sheet(isPresented: $showHelp) { helpSheet.presentationDetents([.medium]) }
        .sheet(isPresented: $showCrash) { crashSheet.presentationDetents([.medium]) }
    }

    // MARK: - header
    private var header: some View {
        HStack(spacing: 6) {
            Button {
                router.screen = .main
            } label: {
                VectorIcon(icon: .back, size: 24, color: Palette.text).frame(width: 52, height: 52)
            }
            .buttonStyle(.plain)
            Text("设置")
                .font(FType.h2())
                .foregroundColor(Palette.text)
            Spacer(minLength: 0)
            Button {
                showScriptSheet = true
            } label: {
                Text("导入音源")
                    .font(FType.body())
                    .foregroundColor(Palette.accent)
                    .padding(.horizontal, 18)
                    .frame(height: 40)
                    .background(Capsule().fill(Palette.accentFill))
                    .overlay(Capsule().stroke(Palette.accentStroke, lineWidth: 1))
            }
            .buttonStyle(.plain)
        }
        .frame(height: 64)
        .padding(.leading, 8)
        .padding(.trailing, 16)
    }

    // MARK: - 下载管理
    private var downloadSection: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Text("下载管理")
                    .font(FType.sectionSm())
                    .foregroundColor(Palette.text)
                Spacer()
                Text("保存在 文件 → CarPlayer/Music")
                    .font(FType.subSm())
                    .foregroundColor(Palette.textSub)
            }
            settingRow(title: "下载音质", value: store.settings.downloadQuality.display) {
                showQuality = true
            }
            settingRow(title: "启动时自动播放", value: store.settings.autoPlayOnLaunch ? "已开启" : "已关闭") {
                store.settings.autoPlayOnLaunch.toggle()
                store.persistAll()
            }
            settingRow(title: "开机自动启动", value: store.settings.bootAutoStart ? "已开启" : "已关闭") {
                store.settings.bootAutoStart.toggle()
                store.persistAll()
            }
            if store.settings.bootAutoStart {
                Text("开机后会自动打开 Music。（iOS 无第三方自启动权限，实际由「车机 CarPlay 自动启动上次播放」实现）")
                    .font(FType.subSm())
                    .foregroundColor(Palette.textSub)
                    .padding(.top, 6)
                    .padding(.horizontal, 4)
            }

            if downloader.jobs.isEmpty {
                Text("还没有下载过音乐")
                    .font(FType.sub())
                    .foregroundColor(Palette.textSub)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 16)
                    .surfaceCard()
                    .padding(.top, 8)
            } else {
                VStack(spacing: 0) {
                    ForEach(downloader.jobs) { job in
                        HStack {
                            Text(job.song.name).font(FType.chip()).foregroundColor(Palette.text).lineLimit(1)
                            Spacer()
                            Text(job.state.rawValue)
                                .font(FType.tiny())
                                .foregroundColor(job.state == .failed ? Palette.danger : Palette.textSub)
                        }
                        .padding(.vertical, 6)
                    }
                }
                .padding(.top, 8)
            }

            Button {
                router.screen = .downloads
            } label: {
                Text("查看下载列表")
                    .font(FType.chip())
                    .foregroundColor(Palette.textSub)
                    .frame(maxWidth: .infinity)
                    .frame(height: 40)
                    .background(Capsule().fill(Palette.surface2))
            }
            .buttonStyle(.plain)
            .padding(.top, 8)
        }
    }

    private func settingRow(title: String, value: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack {
                Text(title).font(FType.body()).foregroundColor(Palette.text)
                Spacer()
                Text(value).font(FType.chip()).foregroundColor(Palette.textSub)
            }
            .padding(.horizontal, 16)
            .frame(height: 52)
            .surfaceCard()
            .padding(.top, 8)
        }
        .buttonStyle(.plain)
    }

    // MARK: - 音源
    private var sourceSectionToggle: some View {
        Button {
            withAnimation(.easeOut(duration: 0.18)) { showSourceSection.toggle() }
        } label: {
            HStack(spacing: 10) {
                Text("音源").font(FType.rowTitle().bold()).foregroundColor(Palette.text)
                Text(sourceSummary)
                    .font(FType.subSm())
                    .foregroundColor(Palette.textSub)
                    .lineLimit(1)
                    .frame(maxWidth: .infinity, alignment: .leading)
                VectorIcon(icon: showSourceSection ? .chevron : .next, size: 20, color: Palette.textSub.opacity(0.6))
            }
            .padding(.horizontal, 16)
            .frame(height: 56)
            .surfaceCard()
            .padding(.top, 22)
        }
        .buttonStyle(.plain)
    }

    private var sourceSummary: String {
        if let qing = store.qing { return "青听 · \(qing.lines.count) 条线路" }
        if !scriptedSources.isEmpty { return scriptedSources.map { $0.name }.joined(separator: " / ") }
        return "未配置"
    }

    private var sourceSection: some View {
        VStack(alignment: .leading, spacing: 8) {
            if let qing = store.qing {
                HStack(alignment: .top, spacing: 12) {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("青听 音源配置")
                            .font(FType.body())
                            .foregroundColor(Palette.text)
                        Text("\(qing.lines.count) 条线路 · \(qing.lines.first?.name ?? "")")
                            .font(FType.subSm())
                            .foregroundColor(Palette.textSub)
                    }
                    Spacer()
                    Button {
                        store.clearQing()
                    } label: {
                        Text("清除")
                            .font(FType.subSm())
                            .foregroundColor(Palette.danger)
                            .padding(.horizontal, 12)
                            .frame(height: 30)
                            .background(Capsule().fill(Palette.surface2))
                    }
                    .buttonStyle(.plain)
                }
                .padding(14)
                .surfaceCard()
            }

            ForEach(scriptedSources) { meta in
                VStack(alignment: .leading, spacing: 4) {
                    HStack {
                        Text(meta.name).font(FType.body()).foregroundColor(Palette.text)
                        Spacer()
                        Text(meta.enabled ? "已启用" : "已停用")
                            .font(FType.tiny())
                            .foregroundColor(meta.enabled ? Palette.accent : Palette.textSub)
                    }
                    Text("支持 \(meta.sources.keys.sorted().joined(separator: " / "))  ·  v\(meta.version)")
                        .font(FType.subSm())
                        .foregroundColor(Palette.textSub)
                    HStack(spacing: 8) {
                        Button {
                            if let index = store.scripts.firstIndex(where: { $0.id == meta.id }) {
                                store.scripts[index].enabled.toggle()
                                store.persistAll()
                            }
                        } label: {
                            Text(meta.enabled ? "停用" : "启用")
                                .font(FType.tiny())
                                .foregroundColor(Palette.textSub)
                                .padding(.horizontal, 10)
                                .frame(height: 26)
                                .background(Capsule().fill(Palette.surface2))
                        }
                        .buttonStyle(.plain)
                        Button {
                            store.removeScript(meta)
                        } label: {
                            Text("删除音源")
                                .font(FType.tiny())
                                .foregroundColor(Palette.danger)
                                .padding(.horizontal, 10)
                                .frame(height: 26)
                                .background(Capsule().fill(Palette.surface2))
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(.top, 2)
                }
                .padding(14)
                .surfaceCard()
            }

            if scriptedSources.isEmpty && store.qing == nil {
                Text("还没有音源。点右上角「导入音源」，把青听的 music.json 网址或 .js 脚本导进来即可。")
                    .font(FType.sub())
                    .foregroundColor(Palette.textSub)
                    .lineSpacing(3)
                    .padding(14)
                    .surfaceCard()
            }

            HStack(spacing: 10) {
                Button {
                    showScriptSheet = true
                } label: {
                    Text("粘贴脚本导入")
                        .font(FType.chip())
                        .foregroundColor(Palette.text)
                        .frame(maxWidth: .infinity)
                        .frame(height: 44)
                        .surfaceCard()
                }
                .buttonStyle(.plain)

                Button {
                    showHelp = true
                } label: {
                    Text("怎么获取音源？")
                        .font(FType.chip())
                        .foregroundColor(Palette.text)
                        .frame(maxWidth: .infinity)
                        .frame(height: 44)
                        .surfaceCard()
                }
                .buttonStyle(.plain)
            }

            Button {
                showQingSheet = true
            } label: {
                HStack {
                    Text("青听音源配置")
                        .font(FType.body())
                        .foregroundColor(Palette.text)
                    Spacer()
                    Text("导入 music.json")
                        .font(FType.subSm())
                        .foregroundColor(Palette.textSub)
                }
                .padding(.horizontal, 16)
                .frame(height: 48)
                .surfaceCard()
            }
            .buttonStyle(.plain)
            .padding(.top, 2)
        }
        .padding(.top, 8)
    }

    // MARK: - 导入歌单
    private var importPlaylistRow: some View {
        Button {
            showPlaylistImport = true
        } label: {
            HStack {
                Text("导入歌单").font(FType.rowTitle()).foregroundColor(Palette.text)
                Spacer()
                Text("QQ / 网易云链接").font(FType.subSm()).foregroundColor(Palette.textSub)
                VectorIcon(icon: .plus, size: 18, color: Palette.textSub.opacity(0.6))
                    .padding(.leading, 8)
            }
            .padding(.horizontal, 16)
            .frame(height: 56)
            .surfaceCard()
            .padding(.top, 10)
        }
        .buttonStyle(.plain)
    }

    // MARK: - 更多设置
    private var moreToggle: some View {
        Button {
            withAnimation(.easeOut(duration: 0.18)) { showMoreSection.toggle() }
        } label: {
            HStack {
                Text("更多设置").font(FType.rowTitle()).foregroundColor(Palette.text)
                Spacer()
                Text("搜索范围 · 诊断").font(FType.subSm()).foregroundColor(Palette.textSub)
                VectorIcon(icon: showMoreSection ? .chevron : .next, size: 20, color: Palette.textSub.opacity(0.6))
                    .padding(.leading, 8)
            }
            .padding(.horizontal, 16)
            .frame(height: 56)
            .surfaceCard()
            .padding(.top, 10)
        }
        .buttonStyle(.plain)
    }

    private var moreSection: some View {
        VStack(alignment: .leading, spacing: 0) {
            Text("搜索范围")
                .font(FType.body().bold())
                .foregroundColor(Palette.text)
                .padding(.top, 16)
            Text("只影响搜索和歌单导入，与播放无关。")
                .font(FType.subSm())
                .foregroundColor(Palette.textSub)
                .padding(.top, 4)
            VStack(spacing: 8) {
                ForEach(SourceId.searchOrder) { source in
                    HStack {
                        Text(source.display).font(FType.body()).foregroundColor(Palette.text)
                        Spacer()
                        Toggle("", isOn: Binding(
                            get: { store.settings.enabledSources.contains(source) },
                            set: { on in
                                var set = store.settings.enabledSources
                                if on { set.insert(source) } else {
                                    if set.count <= 1 { store.show("至少保留一个搜索来源"); return }
                                    set.remove(source)
                                }
                                store.settings.enabledSources = set
                                store.persistAll()
                            }))
                        .labelsHidden()
                        .tint(Palette.accent)
                    }
                    .padding(.horizontal, 16)
                    .frame(height: 46)
                    .surfaceCard()
                }
            }
            .padding(.top, 8)

            Text("诊断")
                .font(FType.body().bold())
                .foregroundColor(Palette.text)
                .padding(.top, 16)
            Text(store.crashLog.isEmpty ? "没有崩溃记录" : String(store.crashLog.prefix(240)))
                .font(FType.sub())
                .foregroundColor(Palette.textSub)
                .lineSpacing(2)
                .padding(14)
                .frame(maxWidth: .infinity, alignment: .leading)
                .surfaceCard()
                .padding(.top, 8)

            Button {
                showCrash = true
            } label: {
                Text("查看上次崩溃日志")
                    .font(FType.body())
                    .foregroundColor(Palette.text)
                    .frame(maxWidth: .infinity)
                    .frame(height: 50)
                    .surfaceCard()
                    .padding(.top, 8)
            }
            .buttonStyle(.plain)
        }
    }

    private var versionRow: some View {
        Text("Music iOS 1.9.14 (build 27) · 适配自 Android com.carplayer.music")
            .font(FType.subSm())
            .foregroundColor(Palette.textSub)
            .frame(maxWidth: .infinity)
            .padding(.top, 22)
    }

    // MARK: - 弹窗
    private var scriptImportSheet: some View {
        sheetContainer(title: "粘贴音源脚本") {
            Text("把 .js 音源脚本的全部内容粘贴到这里；也支持 http/https 网址，或青听 music.json 的网址。")
                .font(FType.sub())
                .foregroundColor(Palette.textSub)
                .padding(.bottom, 10)
            TextEditor(text: $scriptText)
                .font(.system(size: 13, design: .monospaced))
                .foregroundColor(Palette.text)
                .scrollContentBackground(.hidden)
                .background(Palette.surface)
                .frame(height: 160)
                .clipShape(RoundedRectangle(cornerRadius: Radius.surface, style: .continuous))
            HStack(spacing: 10) {
                Button {
                    if let text = UIPasteboard.general.string { scriptText = text }
                } label: {
                    Text("从剪贴板粘贴")
                        .font(FType.chip())
                        .foregroundColor(Palette.text)
                        .frame(maxWidth: .infinity).frame(height: 44)
                        .surfaceCard()
                }
                .buttonStyle(.plain)

                Button {
                    importScript()
                } label: {
                    Text(busy ? "正在导入…" : "导入")
                        .font(FType.chip())
                        .foregroundColor(Palette.accent)
                        .frame(maxWidth: .infinity).frame(height: 44)
                        .background(Capsule().fill(Palette.accentFill))
                        .overlay(Capsule().stroke(Palette.accentStroke, lineWidth: 1))
                }
                .buttonStyle(.plain)
                .disabled(busy)
            }
            .padding(.top, 12)
            Spacer(minLength: 0)
        }
    }

    private var playlistImportSheet: some View {
        sheetContainer(title: "粘贴歌单链接或 ID") {
            Text("支持网易云、QQ 音乐；公开歌单无需登录。")
                .font(FType.sub())
                .foregroundColor(Palette.textSub)
                .padding(.bottom, 10)
            TextEditor(text: $playlistText)
                .font(.system(size: 13))
                .foregroundColor(Palette.text)
                .scrollContentBackground(.hidden)
                .background(Palette.surface)
                .frame(height: 110)
                .clipShape(RoundedRectangle(cornerRadius: Radius.surface, style: .continuous))
            Button {
                importPlaylist()
            } label: {
                Text(busy ? "正在导入…" : "导入歌单")
                    .font(FType.chip())
                    .foregroundColor(Palette.accent)
                    .frame(maxWidth: .infinity).frame(height: 44)
                    .background(Capsule().fill(Palette.accentFill))
                    .overlay(Capsule().stroke(Palette.accentStroke, lineWidth: 1))
            }
            .buttonStyle(.plain)
            .padding(.top, 12)
            Spacer(minLength: 0)
        }
    }

    private var qingSheet: some View {
        sheetContainer(title: "粘贴 music.json 的网址（或整段 JSON）") {
            Text("青听官网提供的那份 music.json 粘进来即可，导入后搜索和播放都走同一套网关。")
                .font(FType.sub())
                .foregroundColor(Palette.textSub)
                .padding(.bottom, 10)
            TextEditor(text: $qingText)
                .font(.system(size: 13, design: .monospaced))
                .foregroundColor(Palette.text)
                .scrollContentBackground(.hidden)
                .background(Palette.surface)
                .frame(height: 160)
                .clipShape(RoundedRectangle(cornerRadius: Radius.surface, style: .continuous))
            Button {
                importQing()
            } label: {
                Text(busy ? "正在导入…" : "导入配置")
                    .font(FType.chip())
                    .foregroundColor(Palette.accent)
                    .frame(maxWidth: .infinity).frame(height: 44)
                    .background(Capsule().fill(Palette.accentFill))
                    .overlay(Capsule().stroke(Palette.accentStroke, lineWidth: 1))
            }
            .buttonStyle(.plain)
            .padding(.top, 12)
            Spacer(minLength: 0)
        }
    }

    private var helpSheet: some View {
        sheetContainer(title: "音源脚本从哪来") {
            ScrollView {
                Text("""
                本应用用的是 LX 自定义源脚本（.js 单文件）。

                1. 从你之前给青听用的那份音源脚本里拿（青听能用的这里都能用）；
                2. 或者找分享的 LX / 洛雪自定义源 .js 文件；
                3. 拿到后用「导入音源」选中即可，导入时会立刻校验能不能跑通。

                脚本支持哪些平台、哪些音质，导入后会在列表里直接写出来。
                """)
                .font(FType.sub())
                .foregroundColor(Palette.textSub)
                .lineSpacing(4)
            }
            Spacer(minLength: 0)
        }
    }

    private var crashSheet: some View {
        sheetContainer(title: "上次崩溃日志") {
            ScrollView {
                Text(store.crashLog.isEmpty ? "没有崩溃记录" : store.crashLog)
                    .font(.system(size: 12, design: .monospaced))
                    .foregroundColor(Palette.textSub)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            Button {
                UIPasteboard.general.string = store.crashLog
                store.show("已复制，发给我即可定位")
            } label: {
                Text("复制")
                    .font(FType.chip())
                    .foregroundColor(Palette.accent)
                    .frame(maxWidth: .infinity).frame(height: 44)
                    .background(Capsule().fill(Palette.accentFill))
            }
            .buttonStyle(.plain)
            .padding(.top, 10)
        }
    }

    private func sheetContainer<Content: View>(title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 0) {
            Text(title)
                .font(FType.sectionSm())
                .foregroundColor(Palette.text)
                .padding(.bottom, 14)
            content()
            Spacer(minLength: 0)
        }
        .padding(20)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .top)
        .background(Palette.sheet.ignoresSafeArea())
    }

    // MARK: - 行为
    private func importScript() {
        let text = scriptText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { store.show("请输入 http/https 网址"); return }
        busy = true
        Task { @MainActor in
            defer { busy = false }
            if text.hasPrefix("http") {
                if let url = URL(string: text), let (data, _) = try? await URLSession.shared.data(from: url),
                   let body = String(data: data, encoding: .utf8) {
                    // music.json 走青听配置，.js 走脚本
                    if body.contains("lx.sources") || body.contains("lx.on") {
                        let message = await store.importScript(text: body)
                        store.show(message)
                        showScriptSheet = false
                    } else {
                        let message = await store.importQing(json: body)
                        store.show(message)
                        showScriptSheet = false
                    }
                } else {
                    store.show("下载失败，检查网址后重试")
                }
            } else {
                let message = await store.importScript(text: text)
                store.show(message)
                if message.hasPrefix("已导入") { showScriptSheet = false }
            }
        }
    }

    private func importQing() {
        let text = qingText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { store.show("请粘贴链接或 JSON"); return }
        busy = true
        Task { @MainActor in
            defer { busy = false }
            let message = await store.importQing(json: text)
            store.show(message)
            if message.hasPrefix("已导入") { showQingSheet = false }
        }
    }

    private func importPlaylist() {
        let text = playlistText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty else { store.show("请粘贴链接"); return }
        guard let (platform, id) = PlaylistImportPlatform.detect(text) else {
            store.show("未识别到歌单 ID")
            return
        }
        busy = true
        Task { @MainActor in
            defer { busy = false }
            let songs = (try? await PlaylistImporter.fetch(platform: platform, id: id)) ?? []
            guard !songs.isEmpty else {
                store.show("歌单不存在或需要登录")
                return
            }
            let playlist = Playlist(id: "\(platform.rawValue)-\(id)",
                                    name: "\(platform.display) \(id)",
                                    songs: songs,
                                    picUrl: songs.first?.picUrl,
                                    source: platform == .wy ? .wy : .tx,
                                    isRemote: true)
            store.replacePlaylist(playlist)
            store.show("已导入「\(playlist.name)」· \(songs.count) 首")
            showPlaylistImport = false
        }
    }
}

/// 歌单导入（网易云 / QQ 公开歌单）
enum PlaylistImporter {
    static func fetch(platform: PlaylistImportPlatform, id: String) async throws -> [Song] {
        switch platform {
        case .wy:
            let url = URL(string: "https://music.163.com/api/v6/playlist/detail?id=\(id)&n=1000&s=0")!
            let (data, _) = try await URLSession.shared.data(from: url)
            guard let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let playlist = obj["playlist"] as? [String: Any],
                  let tracks = playlist["tracks"] as? [[String: Any]] else { throw SourceError.parse }
            return tracks.map { item in
                let artists = (item["ar"] as? [[String: Any]])?.compactMap { $0["name"] as? String }
                    ?? (item["artists"] as? [[String: Any]])?.compactMap { $0["name"] as? String } ?? []
                let album = (item["al"] as? [String: Any]) ?? (item["album"] as? [String: Any])
                return Song(id: String(item["id"] as? Int ?? 0), source: .wy,
                            name: item["name"] as? String ?? "",
                            singer: artists.joined(separator: "/"),
                            albumName: album?["name"] as? String,
                            picUrl: album?["picUrl"] as? String,
                            interval: Double(item["dt"] as? Int ?? item["duration"] as? Int ?? 0) / 1000,
                            qualitys: [.k128, .k320, .flac])
            }
        case .tx:
            let url = URL(string: "https://c.y.qq.com/qzone/fcg-bin/fcg_ucc_getcdinfo_byids_cp.fcg?type=1&json=1&utf8=1&onlysong=0&disstid=\(id)&format=json")!
            var request = URLRequest(url: url)
            request.setValue("https://y.qq.com/", forHTTPHeaderField: "Referer")
            let (data, _) = try await URLSession.shared.data(for: request)
            guard let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let cd = obj["cdlist"] as? [[String: Any]],
                  let disk = cd.first?["songlist"] as? [[String: Any]] else { throw SourceError.parse }
            return disk.map { item in
                let singers = (item["singer"] as? [[String: Any]])?.compactMap { $0["name"] as? String } ?? []
                let mid = item["songmid"] as? String ?? ""
                return Song(id: mid, source: .tx,
                            name: item["songname"] as? String ?? item["name"] as? String ?? "",
                            singer: singers.joined(separator: "/"),
                            albumName: (item["albumname"] as? String) ?? (item["album"] as? [String: Any])?["name"] as? String,
                            picUrl: nil,
                            interval: Double(item["interval"] as? Int ?? 0),
                            qualitys: [.k128, .k320, .flac],
                            extra: ["mid": mid])
            }
        }
    }
}


