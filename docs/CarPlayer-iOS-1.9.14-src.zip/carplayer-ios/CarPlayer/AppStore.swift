import Foundation
import Combine

// 对应 Android com.carplayer.data.Store：全部状态落盘到 Application Support/CarPlayer
struct AppSettings: Codable, Equatable {
    var downloadQuality: Quality = .k320
    var playQuality: Quality = .k320
    var autoPlayOnLaunch: Bool = false
    var bootAutoStart: Bool = false
    var enabledSources: Set<SourceId> = [.kw, .wy, .tx, .mg, .kg]
    var defaultQualityLabel: String = "默认音质"
    var volume: Double = 0.85
    var lastSongId: String?
    var lastPosition: Double = 0
}

@MainActor
final class AppStore: ObservableObject {
    // MARK: - 持久化状态
    @Published var playlists: [Playlist] = []
    @Published var history: [HistoryEntry] = []
    @Published var favorites: [Song] = []
    @Published var downloads: [Song] = []
    @Published var searchHistory: [String] = []
    @Published var settings = AppSettings()
    @Published var scripts: [ScriptMeta] = []
    @Published var qing: QingConfig?

    // MARK: - 运行状态
    @Published var searchKeyword: String = ""
    @Published var searchResults: [Song] = []
    @Published var searchStatus: String = "输入关键词开始搜索"
    @Published var searching: Bool = false
    @Published var hotTx: [Song] = []
    @Published var hotWy: [Song] = []
    @Published var hotTxError: String?
    @Published var hotWyError: String?
    @Published var hotLoading: Bool = false
    @Published var crashLog: String = ""
    @Published var toast: String?

    private let root: URL
    private let engine: LxRuntimeEngine
    private let net: BuiltinSources
    var player: PlayerEngine!

    init() {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("CarPlayer", isDirectory: true)
        try? FileManager.default.createDirectory(at: base, withIntermediateDirectories: true)
        root = base
        engine = LxRuntimeEngine()
        net = BuiltinSources()
        load()
        if playlists.isEmpty { seedDefaultPlaylists() }
        player = PlayerEngine(store: self)
    }

    // MARK: - 文件读写
    private func url(_ name: String) -> URL { root.appendingPathComponent(name + ".json") }

    private func load() {
        playlists = decode([Playlist].self, "playlists") ?? []
        history = decode([HistoryEntry].self, "history") ?? []
        favorites = decode([Song].self, "favorites") ?? []
        downloads = decode([Song].self, "downloads") ?? []
        searchHistory = decode([String].self, "searchHistory") ?? []
        settings = decode(AppSettings.self, "settings") ?? AppSettings()
        scripts = decode([ScriptMeta].self, "scripts") ?? []
        if let q: QingConfig = decode(QingConfig.self, "qing") { qing = q }
        crashLog = (try? String(contentsOf: url("crash"), encoding: .utf8)) ?? ""
    }

    private func decode<T: Decodable>(_ type: T.Type, _ name: String) -> T? {
        guard let data = try? Data(contentsOf: url(name)) else { return nil }
        return try? JSONDecoder().decode(T.self, from: data)
    }

    private func save<T: Encodable>(_ value: T, _ name: String) {
        guard let data = try? JSONEncoder().encode(value) else { return }
        try? data.write(to: url(name), options: .atomic)
    }

    func persistAll() {
        save(playlists, "playlists"); save(history, "history"); save(favorites, "favorites")
        save(downloads, "downloads"); save(searchHistory, "searchHistory")
        save(settings, "settings"); save(scripts, "scripts")
        if let qing { save(qing, "qing") }
    }

    private func seedDefaultPlaylists() {
        playlists = [
            Playlist(id: "favorite", name: "我的收藏", songs: [], picUrl: nil, source: .local, isFavorite: true),
            Playlist(id: "local", name: "本地音乐", songs: [], picUrl: nil, source: .local)
        ]
        save(playlists, "playlists")
    }

    // MARK: - 提示
    func show(_ text: String) {
        toast = text
        Task { @MainActor in
            try? await Task.sleep(nanoseconds: 1_800_000_000)
            if toast == text { toast = nil }
        }
    }

    // MARK: - 歌单
    var favoritePlaylist: Playlist {
        playlists.first(where: { $0.isFavorite }) ??
        Playlist(id: "favorite", name: "我的收藏", songs: [], isFavorite: true)
    }

    func isFavorite(_ song: Song) -> Bool {
        favoritePlaylist.songs.contains { $0.id == song.id && $0.source == song.source }
    }

    func toggleFavorite(_ song: Song) {
        var fav = favoritePlaylist
        if let idx = fav.songs.firstIndex(where: { $0.id == song.id && $0.source == song.source }) {
            fav.songs.remove(at: idx)
            show("已取消收藏")
        } else {
            fav.songs.insert(song, at: 0)
            show("已收藏")
        }
        replacePlaylist(fav)
    }

    func replacePlaylist(_ playlist: Playlist) {
        if let idx = playlists.firstIndex(where: { $0.id == playlist.id }) {
            playlists[idx] = playlist
        } else {
            playlists.append(playlist)
        }
        save(playlists, "playlists")
    }

    func createPlaylist(name: String) -> Playlist {
        let p = Playlist(id: UUID().uuidString, name: name, songs: [])
        playlists.append(p)
        save(playlists, "playlists")
        return p
    }

    func addToPlaylist(_ song: Song, playlistId: String) -> Bool {
        guard var p = playlists.first(where: { $0.id == playlistId }) else { return false }
        if p.songs.contains(where: { $0.id == song.id && $0.source == song.source }) {
            show("「\(p.name)」里已经有这首歌了")
            return false
        }
        p.songs.append(song)
        replacePlaylist(p)
        show("已加入「\(p.name)」")
        return true
    }

    func removeFromPlaylist(_ song: Song, playlistId: String) {
        guard var p = playlists.first(where: { $0.id == playlistId }) else { return }
        p.songs.removeAll { $0.id == song.id && $0.source == song.source }
        replacePlaylist(p)
        show("已移除")
    }

    func deletePlaylist(_ playlist: Playlist) {
        if playlist.isFavorite { show("收藏歌单不可删除"); return }
        playlists.removeAll { $0.id == playlist.id }
        save(playlists, "playlists")
        show("已删除")
    }

    // MARK: - 播放历史
    func addHistory(_ song: Song) {
        history.removeAll { $0.song.id == song.id && $0.song.source == song.source }
        history.insert(HistoryEntry(song: song, source: song.source.rawValue, time: Date()), at: 0)
        if history.count > 100 { history = Array(history.prefix(100)) }   // 最多保留最近 100 首
        save(history, "history")
    }

    func clearHistory() {
        history = []
        save(history, "history")
        show("已清空播放历史")
    }

    func addSearchHistory(_ keyword: String) {
        let k = keyword.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !k.isEmpty else { return }
        searchHistory.removeAll { $0 == k }
        searchHistory.insert(k, at: 0)
        if searchHistory.count > 30 { searchHistory = Array(searchHistory.prefix(30)) }
        save(searchHistory, "searchHistory")
    }

    func clearSearchHistory() {
        searchHistory = []
        save(searchHistory, "searchHistory")
        show("已清空搜索历史")
    }

    // MARK: - 搜索
    func search(_ keyword: String) {
        let k = keyword.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !k.isEmpty else {
            searchStatus = "请输入关键词"
            return
        }
        searchKeyword = k
        addSearchHistory(k)
        searching = true
        searchStatus = "搜索中…"
        searchResults = []

        let sources = SourceId.searchOrder.filter { settings.enabledSources.contains($0) }
        if sources.isEmpty {
            searching = false
            searchStatus = "至少保留一个搜索来源"
            return
        }

        Task { @MainActor in
            var all: [Song] = []
            var errors: [String] = []
            for source in sources {
                do {
                    let songs = try await net.search(source: source, keyword: k)
                    all.append(contentsOf: songs)
                } catch {
                    errors.append("\(source.display)搜索失败")
                }
            }
            // 自定义脚本音源（lx 脚本 / 青听网关）补充
            if let scriptSongs = await engineSearch(k) { all.append(contentsOf: scriptSongs) }
            searching = false
            searchResults = all
            if all.isEmpty {
                searchStatus = errors.isEmpty ? "没有结果，换个关键词试试" : "搜索失败：\(errors.joined(separator: "，"))"
            } else {
                searchStatus = "共 \(all.count) 首 · \(sources.map { $0.display }.joined(separator: " / "))"
            }
        }
    }

    private func engineSearch(_ keyword: String) async -> [Song]? {
        // lx 脚本只负责 musicUrl/lyric/pic，搜索仍由内置源 + 青听网关完成
        if let qing {
            return try? await QingGate.search(keyword: keyword, config: qing)
        }
        return nil
    }

    // MARK: - 首页热歌榜
    func loadHotCharts(force: Bool = false) {
        guard !hotLoading else { return }
        hotLoading = true
        hotTxError = nil
        hotWyError = nil
        Task { @MainActor in
            async let tx = net.hotChart(source: .tx)
            async let wy = net.hotChart(source: .wy)
            let (t, w) = await (tx, wy)
            hotLoading = false
            hotTx = t
            hotWy = w
            if t.isEmpty { hotTxError = "加载失败" }
            if w.isEmpty { hotWyError = "加载失败" }
        }
    }

    func shuffleHot() {
        hotTx.shuffle()
        hotWy.shuffle()
    }

    // MARK: - 音源脚本
    func importScript(text: String) async -> String {
        guard text.contains("lx.sources") || text.contains("lx.on") else {
            return "这不像是音源脚本（缺少 lx.sources）"
        }
        let meta = await engine.probe(script: text)
        guard let meta else { return "脚本注入失败：脚本环境加载失败" }
        scripts.removeAll { $0.id == meta.id }
        scripts.append(meta)
        save(scripts, "scripts")
        return "已导入「\(meta.name)」，支持 \(meta.sources.keys.joined(separator: "/"))"
    }

    func removeScript(_ meta: ScriptMeta) {
        scripts.removeAll { $0.id == meta.id }
        save(scripts, "scripts")
    }

    func importQing(json: String) async -> String {
        guard let config = QingConfig.parse(json: json) else {
            if json.trimmingCharacters(in: .whitespacesAndNewlines).hasPrefix("http") {
                do {
                    let (data, _) = try await URLSession.shared.data(from: URL(string: json)!)
                    if let text = String(data: data, encoding: .utf8), let c = QingConfig.parse(json: text) {
                        qing = c
                        save(c, "qing")
                        return "已导入「青听音源配置」· \(c.lines.count) 条线路"
                    }
                } catch {
                    return "下载失败，检查网址后重试"
                }
            }
            return "这份内容没能解析成青听音源配置。"
        }
        qing = config
        save(config, "qing")
        return "已导入「青听音源配置」· \(config.lines.count) 条线路"
    }

    func clearQing() {
        qing = nil
        try? FileManager.default.removeItem(at: url("qing"))
        show("已清除")
    }

    // MARK: - 播放封装
    func play(song: Song, queue: [Song]? = nil) {
        player.play(song: song, queue: queue ?? [song])
    }

    func playAll(_ songs: [Song], startAt index: Int = 0) {
        guard !songs.isEmpty else { show("歌单是空的"); return }
        player.play(song: songs[min(index, songs.count - 1)], queue: songs)
    }

    /// 取播放地址：脚本音源 → 青听网关 → 内置直连
    func resolveURL(for song: Song, quality: Quality) async throws -> URL {
        if song.source == .local, let path = song.localPath {
            return URL(fileURLWithPath: path)
        }
        if let qing {
            if let url = try? await QingGate.resolveURL(song: song, quality: quality, config: qing) {
                return url
            }
        }
        let enabled = scripts.filter { $0.enabled && $0.sources.keys.contains(song.source.rawValue) }
        for meta in enabled {
            if let url = try? await engine.musicURL(meta: meta, song: song, quality: quality) {
                return url
            }
        }
        return try await net.resolveURL(song: song, quality: quality)
    }

    func resolveLyric(for song: Song) async -> Lyric? {
        if let qing, let lrc = try? await QingGate.lyric(song: song, config: qing) {
            return Lyric.parse(lrc)
        }
        let enabled = scripts.filter { $0.enabled }
        for meta in enabled {
            if let lrc = try? await engine.lyric(meta: meta, song: song) {
                return Lyric.parse(lrc)
            }
        }
        if let lrc = try? await net.lyric(song: song) { return Lyric.parse(lrc) }
        return nil
    }
}
