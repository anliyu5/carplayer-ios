import SwiftUI

/// 下载页：对齐 view_download（res/Mq.xml）
struct DownloadView: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var router: Router
    @ObservedObject private var downloader = Downloader.shared
    @State private var showQuality = false

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 6) {
                Button {
                    router.screen = .main
                } label: {
                    VectorIcon(icon: .back, size: 24, color: Palette.text)
                        .frame(width: 52, height: 52)
                }
                .buttonStyle(.plain)
                Text("下载")
                    .font(FType.h2())
                    .foregroundColor(Palette.text)
                Spacer(minLength: 0)
            }
            .frame(height: 64)
            .padding(.leading, 8)
            .padding(.trailing, 16)

            qualityRow
                .padding(.horizontal, 20)
                .padding(.top, 8)

            content
        }
        .background(Palette.bg.ignoresSafeArea())
        .confirmationDialog("下载音质", isPresented: $showQuality, titleVisibility: .visible) {
            ForEach(Quality.downloadOptions) { quality in
                Button(quality.display) {
                    store.settings.downloadQuality = quality
                    store.persistAll()
                }
            }
            Button("取消", role: .cancel) {}
        }
    }

    private var qualityRow: some View {
        HStack(spacing: 0) {
            VectorIcon(icon: .download, size: 22, color: Palette.textSub)
            Text("下载音质")
                .font(FType.rowTitle())
                .foregroundColor(Palette.text)
                .padding(.leading, 14)
            Spacer()
            Text(store.settings.downloadQuality.display)
                .font(FType.chip().bold())
                .foregroundColor(Palette.accent)
            VectorIcon(icon: .next, size: 22, color: Palette.textSub.opacity(0.6))
                .padding(.leading, 6)
        }
        .padding(.horizontal, 18)
        .frame(height: 58)
        .background(RoundedRectangle(cornerRadius: Radius.card, style: .continuous).fill(Palette.card))
        .contentShape(Rectangle())
        .onTapGesture { showQuality = true }
    }

    @ViewBuilder
    private var content: some View {
        if downloader.jobs.isEmpty && store.downloads.isEmpty {
            VStack(spacing: 0) {
                Spacer()
                VectorIcon(icon: .download, size: 46, color: Palette.text.sub(0.35))
                Text("还没有下载的歌曲")
                    .font(FType.rowTitle())
                    .foregroundColor(Palette.text)
                    .padding(.top, 14)
                Text("搜索到歌曲后点列表右侧「⋮」→「下载」，文件会存到 文件 → CarPlayer/Music，这里也能直接播放。")
                    .font(FType.sub())
                    .foregroundColor(Palette.textSub)
                    .multilineTextAlignment(.center)
                    .lineSpacing(3)
                    .padding(.top, 8)
                Spacer()
            }
            .padding(.horizontal, 40)
        } else {
            ScrollView(showsIndicators: false) {
                LazyVStack(spacing: 0) {
                    if !downloader.jobs.isEmpty {
                        ForEach(downloader.jobs) { job in
                            HStack(spacing: 12) {
                                VectorIcon(icon: .note, size: 20, color: Palette.textSub)
                                VStack(alignment: .leading, spacing: 4) {
                                    Text("\(job.song.name)")
                                        .font(FType.chip())
                                        .foregroundColor(Palette.text)
                                        .lineLimit(1)
                                    ProgressView(value: job.progress)
                                        .tint(Palette.accent)
                                }
                                Text(job.state.rawValue)
                                    .font(FType.tiny())
                                    .foregroundColor(job.state == .failed ? Palette.danger : Palette.textSub)
                            }
                            .padding(.vertical, 8)
                        }
                    }
                    ForEach(Array(store.downloads.enumerated()), id: \.element.id) { index, song in
                        SongRowView(song: song, index: index + 1, showQuality: false) {
                            store.playAll(store.downloads, startAt: index)
                            router.screen = .player
                        } onMore: {
                            store.show("本地音乐不可删除")
                        }
                    }
                }
                .padding(.horizontal, 20)
                .padding(.top, 4)
                .padding(.bottom, 16)
            }
        }
    }
}

extension Color {
    func `sub`(_ alpha: Double) -> Color { self.opacity(alpha) }
}
