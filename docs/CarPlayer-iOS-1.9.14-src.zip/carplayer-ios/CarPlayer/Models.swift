import Foundation

// 与 Android 侧 com.carplayer.data.Song / Playlist / HistoryEntry 字段一一对应
enum SourceId: String, Codable, CaseIterable, Identifiable {
    case kw, kg, tx, wy, mg, qs, local
    var id: String { rawValue }

    /// 音源中文名，取自 aria/字符串表
    var display: String {
        switch self {
        case .kw: return "酷我"
        case .kg: return "酷狗"
        case .tx: return "QQ"
        case .wy: return "网易"
        case .mg: return "咪咕"
        case .qs: return "汽水"
        case .local: return "本地"
        }
    }

    /// SourceEngine 的展示顺序：kw 搜索结果最全 → wy → tx → mg → kg → 聚合
    static let searchOrder: [SourceId] = [.kw, .wy, .tx, .mg, .kg]
}

enum Quality: String, Codable, CaseIterable, Identifiable {
    case k128, k320, flac, flac24bit, hires, atmos, master, atmos_plus, spatial
    var id: String { rawValue }

    var display: String {
        switch self {
        case .k128: return "标准 128K"
        case .k320: return "较高 320K"
        case .flac: return "无损 FLAC"
        case .flac24bit: return "超清母带FLAC"
        case .hires: return "高清环绕"
        case .atmos: return "全景声"
        case .master: return "母带"
        case .atmos_plus: return "全景声 Plus"
        case .spatial: return "沉浸环绕"
        }
    }

    /// 列表右侧音质角标（songQuality）
    var badge: String {
        switch self {
        case .k128: return "128K"
        case .k320: return "320K"
        case .flac: return "FLAC"
        case .flac24bit: return "24bit"
        case .hires: return "Hi-Res"
        case .atmos: return "全景声"
        case .master: return "母带"
        case .atmos_plus: return "全景声+"
        case .spatial: return "空间"
        }
    }

    /// lx 脚本用的音质 key
    var lxKey: String {
        switch self {
        case .k128: return "128k"
        case .k320: return "320k"
        case .flac: return "flac"
        case .flac24bit: return "flac24bit"
        case .hires: return "hires"
        case .atmos: return "atmos"
        case .master: return "master"
        case .atmos_plus: return "atmos_plus"
        case .spatial: return "spatial"
        }
    }

    static func fromLxKey(_ key: String) -> Quality? {
        Quality.allCases.first { $0.lxKey == key }
    }

    /// 下载音质档位（设置页「下载音质」）
    static let downloadOptions: [Quality] = [.k320, .flac, .flac24bit, .master]
}

struct Song: Identifiable, Codable, Hashable {
    var id: String                    // 平台原始 ID
    var source: SourceId
    var name: String
    var singer: String
    var albumName: String?
    var picUrl: String?
    var interval: Double              // 秒
    var qualitys: [Quality]
    var localPath: String?
    /// 平台附加字段（songmid / hash / copyrightId / rid …），各音源解析时自行取用
    var extra: [String: String] = [:]

    var displaySinger: String { singer.isEmpty ? "未知歌手" : singer }
    var displayAlbum: String { (albumName?.isEmpty == false) ? albumName! : "未知专辑" }
    var bestQuality: Quality? { qualitys.max(by: { Quality.allCases.firstIndex(of: $0)! < Quality.allCases.firstIndex(of: $1)! }) }
    var isLocal: Bool { source == .local }
}

struct Playlist: Identifiable, Codable, Hashable {
    var id: String
    var name: String
    var songs: [Song]
    var picUrl: String?
    var source: SourceId = .local
    var isFavorite: Bool = false
    var isRemote: Bool = false          // 远程导入歌单（网易云/QQ），不可删除以外行为一致

    var count: Int { songs.count }
    var subtitle: String {
        let owner = source == .local ? "我的歌单" : "\(source.display)歌单"
        return "\(owner) · \(count) 首"
    }
}

struct HistoryEntry: Identifiable, Codable, Hashable {
    var id: String { song.id + "-" + source + "-" + String(time.timeIntervalSince1970) }
    var song: Song
    var source: String
    var time: Date

    enum CodingKeys: String, CodingKey { case song, source, time }
}

struct SearchRow: Identifiable, Codable, Hashable {
    var id: String { song.source.rawValue + ":" + song.id }
    var song: Song
    var index: Int
}

enum PlayMode: String, Codable, CaseIterable {
    case order, repeatOne, shuffle
    var display: String {
        switch self {
        case .order: return "顺序播放"
        case .repeatOne: return "单曲循环"
        case .shuffle: return "随机播放"
        }
    }
    var icon: Icon {
        switch self {
        case .order: return .repeatAll
        case .repeatOne: return .repeatOne
        case .shuffle: return .shuffle
        }
    }
    var next: PlayMode {
        switch self {
        case .order: return .repeatOne
        case .repeatOne: return .shuffle
        case .shuffle: return .order
        }
    }
}

/// 导入后的音源脚本元数据（对应 ScriptMeta / SourceCap）
struct ScriptMeta: Codable, Hashable, Identifiable {
    var id: String            // sha1
    var name: String
    var version: String
    var author: String
    var description: String
    var homepage: String
    var sources: [String: [String]]   // source -> qualitys
    var enabled: Bool = true
    var script: String
    var initedAt: Date = Date()
}

/// 青听网关音源配置（QingConfig / QingLine）
struct QingConfig: Codable, Hashable {
    struct Line: Codable, Hashable, Identifiable {
        var id: String { name }
        var name: String
        var url: String
        var type: String
    }
    var lines: [Line]
    var raw: String

    static func parse(json: String) -> QingConfig? {
        guard let data = json.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return nil }
        guard let linesArr = obj["lines"] as? [[String: Any]] else { return nil }
        let lines: [QingConfig.Line] = linesArr.compactMap { item in
            guard let name = (item["name"] as? String) ?? (item["id"] as? String) else { return nil }
            let url = (item["url"] as? String) ?? (item["api"] as? String) ?? ""
            let type = (item["type"] as? String) ?? "music"
            return QingConfig.Line(name: name, url: url, type: type)
        }
        guard !lines.isEmpty else { return nil }
        return QingConfig(lines: lines, raw: json)
    }
}

/// 歌单导入用的平台
enum PlaylistImportPlatform: String {
    case wy, tx
    var display: String { self == .wy ? "网易云歌单" : "QQ 歌单" }

    /// 从链接/文本里解析歌单 ID
    static func detect(_ text: String) -> (PlaylistImportPlatform, String)? {
        let t = text.trimmingCharacters(in: .whitespacesAndNewlines)
        if let r = t.range(of: #"music\.163\.com[^\s]*[?&]id=(\d+)"#, options: .regularExpression),
           let idRange = t.range(of: #"id=\d+"#, range: r) {
            return (.wy, String(t[idRange].dropFirst(3)))
        }
        if let r = t.range(of: #"y\.qq\.com[^\s]*[?&]id=(\d+)"#, options: .regularExpression),
           let idRange = t.range(of: #"id=\d+"#, range: r) {
            return (.tx, String(t[idRange].dropFirst(3)))
        }
        if t.allSatisfy({ $0.isNumber }) && !t.isEmpty {
            return (.wy, t)
        }
        return nil
    }
}
