import Foundation

/// 青听网关（对应 Android com.carplayer.source.qing.QingGate / QingLine / QingSearch）
///
/// 配置来自用户粘贴的 music.json：{ "lines": [ { "name": "...", "url": "https://...", "type": "music" } ] }
/// 网关接口契约（与 Android 侧一致，可按你实际部署调整路径）：
///   GET  {line}/search?keyword=K&limit=30        -> { code:0, data:[ {id, name, singer, album, duration, pic, sources} ] }
///   GET  {line}/url?source=kw&id=ID&quality=320k -> { code:0, data:{ url } }
///   GET  {line}/lyric?source=kw&id=ID            -> { code:0, data:{ lyric, tlyric } }
enum QingGate {
    static func search(keyword: String, config: QingConfig) async throws -> [Song] {
        var out: [Song] = []
        var lastError: Error?
        for line in config.lines {
            do {
                guard var comps = URLComponents(string: line.url + "/search") else { continue }
                comps.queryItems = [
                    URLQueryItem(name: "keyword", value: keyword),
                    URLQueryItem(name: "limit", value: "30")
                ]
                guard let url = comps.url else { continue }
                let (data, _) = try await URLSession.shared.data(from: url)
                out.append(contentsOf: parseSearch(data))
            } catch {
                lastError = error
            }
        }
        if out.isEmpty, let lastError { throw lastError }
        return out
    }

    static func resolveURL(song: Song, quality: Quality, config: QingConfig) async throws -> URL? {
        for line in config.lines {
            guard var comps = URLComponents(string: line.url + "/url") else { continue }
            comps.queryItems = [
                URLQueryItem(name: "source", value: song.source.rawValue),
                URLQueryItem(name: "id", value: song.id),
                URLQueryItem(name: "quality", value: quality.lxKey)
            ]
            guard let url = comps.url else { continue }
            guard let (data, _) = try? await URLSession.shared.data(from: url) else { continue }
            if let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let payload = obj["data"] as? [String: Any],
               let str = payload["url"] as? String,
               let target = URL(string: str), target.scheme?.hasPrefix("http") == true {
                return target
            }
        }
        return nil
    }

    static func lyric(song: Song, config: QingConfig) async throws -> String? {
        for line in config.lines {
            guard var comps = URLComponents(string: line.url + "/lyric") else { continue }
            comps.queryItems = [
                URLQueryItem(name: "source", value: song.source.rawValue),
                URLQueryItem(name: "id", value: song.id)
            ]
            guard let url = comps.url else { continue }
            guard let (data, _) = try? await URLSession.shared.data(from: url) else { continue }
            if let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let payload = obj["data"] as? [String: Any],
               let lrc = payload["lyric"] as? String {
                return lrc
            }
        }
        return nil
    }

    private static func parseSearch(_ data: Data) -> [Song] {
        guard let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return [] }
        let list = (obj["data"] as? [[String: Any]]) ?? (obj["songs"] as? [[String: Any]]) ?? []
        return list.compactMap { item in
            let sourceName = item["source"] as? String ?? "kw"
            guard let source = SourceId(rawValue: sourceName) else { return nil }
            let id = item["id"].map { "\($0)" } ?? ""
            guard !id.isEmpty else { return nil }
            let qualitys = (item["qualitys"] as? [String])?.compactMap { Quality.fromLxKey($0) } ?? [.k128, .k320]
            return Song(id: id,
                        source: source,
                        name: item["name"] as? String ?? "",
                        singer: item["singer"] as? String ?? "",
                        albumName: item["album"] as? String,
                        picUrl: item["pic"] as? String,
                        interval: Double(item["duration"] as? Int ?? 0),
                        qualitys: qualitys)
        }
    }
}
