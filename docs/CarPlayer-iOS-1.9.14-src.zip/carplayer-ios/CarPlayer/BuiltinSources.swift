﻿import Foundation

/// 内置搜索适配层（对应 Android com.carplayer.source.SourceEngine）
///
/// 说明：与 Android 版保持一致 —— 内置的只是「搜索 + 榜单」骨架，
/// 真正的播放地址解析走「自定义 lx 脚本」或「青听网关」，两者都在设置页导入。
/// 如果你在自己的部署里已经有一整套直连接口，把 EndpointBook 里的模板换成你的即可，
/// 解析代码不用动。
struct EndpointBook: Codable {
    var search: [String: String] = [
        "kw": "http://search.kuwo.cn/r.s?all={keyword}&ft=music&itemset=web_2013&client=kt&pn=0&rn=30&rformat=json&encoding=utf8",
        "wy": "https://music.163.com/api/search/get?s={keyword}&type=1&limit=30&offset=0",
        "tx": "https://c.y.qq.com/soso/fcgi-bin/client_search_cp?w={keyword}&format=json&n=30&p=1&cr=1&new_json=1",
        "mg": "https://m.music.migu.cn/migu/remoting/scr_search_tag?keyword={keyword}&type=2&rows=20&pgc=1",
        "kg": "https://mobilecdn.kugou.com/api/v3/search/song?keyword={keyword}&page=1&pagesize=30&showtype=1"
    ]
    var chart: [String: String] = [
        "tx": "https://u.y.qq.com/cgi-bin/musicu.fcg?format=json&g_tk=5381&topid={TOPID}&num=20",
        "wy": "https://music.163.com/api/playlist/detail?id=3778678"
    ]
    /// 直连解析（可选）：{id} / {quality} 占位
    var resolve: [String: String] = [:]
    var lyric: [String: String] = [:]

    static func load() -> EndpointBook {
        guard let data = UserDefaults.standard.data(forKey: "endpoint.book"),
              let book = try? JSONDecoder().decode(EndpointBook.self, from: data) else { return EndpointBook() }
        return book
    }

    func save() {
        if let data = try? JSONEncoder().encode(self) {
            UserDefaults.standard.set(data, forKey: "endpoint.book")
        }
    }
}

final class BuiltinSources {
    private let session: URLSession
    private let book = EndpointBook.load()

    init() {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 12
        config.httpAdditionalHeaders = [
            "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148",
            "Referer": "https://music.163.com/"
        ]
        session = URLSession(configuration: config)
    }

    private func get(_ urlString: String) async throws -> Data {
        guard let url = URL(string: urlString) else { throw SourceError.badURL }
        let (data, _) = try await session.data(from: url)
        return data
    }

    private func fill(_ template: String, _ map: [String: String]) -> String {
        var out = template
        for (k, v) in map {
            out = out.replacingOccurrences(of: "{\(k)}", with: v.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? v)
        }
        return out
    }

    // MARK: - 搜索
    func search(source: SourceId, keyword: String) async throws -> [Song] {
        guard let template = book.search[source.rawValue] else { throw SourceError.unsupported }
        let data = try await get(fill(template, ["keyword": keyword]))
        return parseSearch(source: source, data: data)
    }

    private func parseSearch(source: SourceId, data: Data) -> [Song] {
        guard let obj = try? JSONSerialization.jsonObject(with: data) else { return [] }
        switch source {
        case .kw:
            if let dict = obj as? [String: Any], let abs = extractKw(dict) { return abs }
            if let text = String(data: data, encoding: .utf8) { return KwTextParser.parse(text) }
            return []
        case .wy:
            guard let dict = obj as? [String: Any],
                  let result = dict["result"] as? [String: Any],
                  let songs = result["songs"] as? [[String: Any]] else { return [] }
            return songs.map { item in
                let artists = (item["artists"] as? [[String: Any]])?.compactMap { $0["name"] as? String } ?? []
                let album = item["album"] as? [String: Any]
                return Song(id: String(item["id"] as? Int ?? 0),
                            source: .wy,
                            name: item["name"] as? String ?? "",
                            singer: artists.joined(separator: "/"),
                            albumName: album?["name"] as? String,
                            picUrl: album?["picUrl"] as? String,
                            interval: Double(item["duration"] as? Int ?? 0) / 1000,
                            qualitys: [.k128, .k320, .flac])
            }
        case .tx:
            guard let dict = obj as? [String: Any],
                  let dataDict = dict["data"] as? [String: Any],
                  let songDict = dataDict["song"] as? [String: Any],
                  let list = songDict["list"] as? [[String: Any]] else { return [] }
            return list.map { item in
                let singers = (item["singer"] as? [[String: Any]])?.compactMap { $0["name"] as? String } ?? []
                let album = item["album"] as? [String: Any]
                let mid = item["mid"] as? String ?? item["songmid"] as? String ?? ""
                let id = mid.isEmpty ? String(item["songid"] as? Int ?? 0) : mid
                return Song(id: id,
                            source: .tx,
                            name: item["title"] as? String ?? item["songname"] as? String ?? "",
                            singer: singers.joined(separator: "/"),
                            albumName: album?["name"] as? String ?? (album?["title"] as? String),
                            picUrl: album?["pmid"].flatMap { "https://y.gtimg.cn/music/photo_new/T002R300x300M000\($0).jpg" },
                            interval: Double(item["interval"] as? Int ?? 0),
                            qualitys: [.k128, .k320, .flac],
                            extra: ["mid": mid])
            }
        case .mg:
            guard let dict = obj as? [String: Any], let list = dict["musics"] as? [[String: Any]] else { return [] }
            return list.map { item in
                Song(id: item["copyrightId"] as? String ?? item["id"] as? String ?? "",
                     source: .mg,
                     name: item["songName"] as? String ?? item["name"] as? String ?? "",
                     singer: item["singerName"] as? String ?? "",
                     albumName: item["albumName"] as? String,
                     picUrl: item["cover"] as? String,
                     interval: Double(item["length"] as? String ?? "0") ?? 0,
                     qualitys: [.k128, .k320, .flac])
            }
        case .kg:
            guard let dict = obj as? [String: Any],
                  let dataDict = dict["data"] as? [String: Any],
                  let info = dataDict["info"] as? [[String: Any]] else { return [] }
            return info.map { item in
                Song(id: item["hash"] as? String ?? "",
                     source: .kg,
                     name: item["songname"] as? String ?? "",
                     singer: item["singername"] as? String ?? "",
                     albumName: item["album_name"] as? String,
                     picUrl: nil,
                     interval: Double(item["duration"] as? Int ?? 0),
                     qualitys: [.k128, .k320, .flac],
                     extra: ["album_id": String(item["album_id"] as? Int ?? 0)])
            }
        default:
            return []
        }
    }

    private func extractKw(_ dict: [String: Any]) -> [Song]? {
        guard let list = dict["abslist"] as? [[String: Any]] else { return nil }
        return list.map { item in
            Song(id: String(item["MUSICRID"] as? String ?? "").replacingOccurrences(of: "MUSIC_", with: ""),
                 source: .kw,
                 name: item["SONGNAME"] as? String ?? "",
                 singer: item["ARTIST"] as? String ?? "",
                 albumName: item["ALBUM"] as? String,
                 picUrl: nil,
                 interval: Double(item["DURATION"] as? String ?? "0") ?? 0,
                 qualitys: [.k128, .k320, .flac],
                 extra: ["rid": String(item["MUSICRID"] as? String ?? "").replacingOccurrences(of: "MUSIC_", with: "")])
        }
    }

    // MARK: - 榜单（首页「小Q热歌 / 小云热歌」）
    func hotChart(source: SourceId) async -> [Song] {
        guard let template = book.chart[source.rawValue] else { return [] }
        do {
            let data = try await get(fill(template, ["TOPID": source == .tx ? "26" : "3778678"]))
            switch source {
            case .tx:
                guard let dict = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                      let detail = (dict["detail"] as? [String: Any]),
                      let dataDict = detail["data"] as? [String: Any],
                      let songs = dataDict["songInfoList"] as? [[String: Any]] else { return [] }
                return songs.prefix(20).enumerated().map { idx, item in
                    let singers = (item["singer"] as? [[String: Any]])?.compactMap { $0["name"] as? String } ?? []
                    let mid = item["mid"] as? String ?? ""
                    return Song(id: mid.isEmpty ? String(idx) : mid, source: .tx,
                                name: item["title"] as? String ?? item["name"] as? String ?? "",
                                singer: singers.joined(separator: "/"),
                                albumName: (item["album"] as? [String: Any])?["name"] as? String,
                                picUrl: nil, interval: Double(item["interval"] as? Int ?? 0),
                                qualitys: [.k128, .k320, .flac], extra: ["mid": mid])
                }
            case .wy:
                guard let dict = try JSONSerialization.jsonObject(with: data) as? [String: Any],
                      let result = dict["result"] as? [String: Any],
                      let tracks = result["tracks"] as? [[String: Any]] else { return [] }
                return tracks.prefix(20).map { item in
                    let artists = (item["artists"] as? [[String: Any]])?.compactMap { $0["name"] as? String } ?? []
                    let album = item["album"] as? [String: Any]
                    return Song(id: String(item["id"] as? Int ?? 0), source: .wy,
                                name: item["name"] as? String ?? "",
                                singer: artists.joined(separator: "/"),
                                albumName: album?["name"] as? String,
                                picUrl: album?["picUrl"] as? String,
                                interval: Double(item["duration"] as? Int ?? 0) / 1000,
                                qualitys: [.k128, .k320, .flac])
                }
            default:
                return []
            }
        } catch {
            return []
        }
    }

    // MARK: - 直连解析（EndpointBook.resolve 未配置时抛错，交由脚本/网关处理）
    func resolveURL(song: Song, quality: Quality) async throws -> URL {
        guard let template = book.resolve[song.source.rawValue] else {
            throw SourceError.noResolver("音源未返回播放地址（\(song.source.display)）。请在设置里导入音源脚本或青听配置")
        }
        let urlString = fill(template, ["id": song.id, "quality": quality.lxKey])
        guard let url = URL(string: urlString) else { throw SourceError.badURL }
        return url
    }

    func lyric(song: Song) async throws -> String? {
        guard let template = book.lyric[song.source.rawValue] else { return nil }
        let data = try await get(fill(template, ["id": song.id]))
        if let dict = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
            return dict["lrc"] as? String ?? dict["lyric"] as? String
        }
        return String(data: data, encoding: .utf8)
    }
}

enum SourceError: LocalizedError {
    case badURL, unsupported, noResolver(String), parse

    var errorDescription: String? {
        switch self {
        case .badURL: return "请求地址为空"
        case .unsupported: return "该平台暂不支持"
        case .noResolver(let msg): return msg
        case .parse: return "解析失败"
        }
    }
}

/// 酷我老接口返回的是「单引号伪 JSON」，Android 侧同样要文本兜底解析
enum KwTextParser {
    static func parse(_ text: String) -> [Song] {
        var songs: [Song] = []
        let blocks = text.components(separatedBy: "MUSICRID:'MUSIC_")
        for block in blocks.dropFirst() {
            func field(_ key: String) -> String? {
                let pattern = "\(key):'([^']*)'"
                guard let r = block.range(of: pattern, options: .regularExpression) else { return nil }
                let matched = String(block[r])
                return matched.components(separatedBy: "'").dropFirst().first
            }
            let id = block.components(separatedBy: "'").first ?? ""
            let name = field("SONGNAME") ?? ""
            let artist = field("ARTIST") ?? ""
            let album = field("ALBUM") ?? ""
            let duration = Double(field("DURATION") ?? "0") ?? 0
            if !name.isEmpty {
                songs.append(Song(id: id, source: .kw, name: name, singer: artist,
                                  albumName: album, picUrl: nil, interval: duration,
                                  qualitys: [.k128, .k320, .flac], extra: ["rid": id]))
            }
        }
        return songs
    }
}

