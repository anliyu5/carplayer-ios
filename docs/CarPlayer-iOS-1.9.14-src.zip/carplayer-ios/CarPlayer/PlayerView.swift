import SwiftUI

/// 播放页（Android 侧 PlayerActivity 为纯代码构建视图，此处按同一套设计令牌 1:1 还原）
struct PlayerView: View {
    @EnvironmentObject private var store: AppStore
    @EnvironmentObject private var router: Router
    @State private var dragging: Double?
    @State private var showQueue = false
    @State private var showQuality = false

    private var player: PlayerEngine { store.player }
    private var song: Song? { player.current }

    var body: some View {
        VStack(spacing: 0) {
            topBar
            if let song {
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 0) {
                        cover(song)
                        titleBlock(song)
                        lyricBlock
                        progressBlock
                        controls
                        bottomRow(song)
                    }
                    .padding(.horizontal, 24)
                    .padding(.bottom, 24)
                }
            } else {
                VStack {
                    Spacer()
                    Text("当前没有正在播放的歌曲")
                        .font(FType.rowTitle())
                        .foregroundColor(Palette.textSub)
                    Spacer()
                }
            }
        }
        .background(Palette.bg.ignoresSafeArea())
        .sheet(isPresented: $showQueue) {
            QueueSheet()
                .presentationDetents([.medium, .large])
        }
        .confirmationDialog("音质", isPresented: $showQuality, titleVisibility: .visible) {
            ForEach(song?.qualitys ?? [.k320]) { quality in
                Button(quality.display) {
                    store.settings.playQuality = quality
                    store.persistAll()
                    store.show("音质已设为 \(quality.display)")
                }
            }
            Button("取消", role: .cancel) {}
        }
    }

    private var topBar: some View {
        HStack(spacing: 6) {
            Button {
                router.screen = .main
            } label: {
                VectorIcon(icon: .back, size: 24, color: Palette.text).frame(width: 52, height: 52)
            }
            .buttonStyle(.plain)
            .accessibilityLabel("返回")
            Text("正在播放")
                .font(FType.body().bold())
                .foregroundColor(Palette.text)
            Spacer(minLength: 0)
            Text(player.mode.display)
                .font(FType.chip())
                .foregroundColor(Palette.accent)
                .padding(.horizontal, 12)
                .frame(height: 30)
                .background(Capsule().fill(Palette.accentFill))
                .overlay(Capsule().stroke(Palette.accentStroke, lineWidth: 1))
            Button {
                showQueue = true
            } label: {
                VectorIcon(icon: .library, size: 22, color: Palette.text).frame(width: 48, height: 48)
            }
            .buttonStyle(.plain)
            .accessibilityLabel("播放列表")
        }
        .frame(height: 60)
        .padding(.leading, 8)
        .padding(.trailing, 12)
    }

    private func cover(_ song: Song) -> some View {
        ZStack(alignment: .bottom) {
            CoverBanner(url: song.picUrl, radius: Radius.cover)
                .frame(height: 220)
            LinearGradient(colors: [.clear, Color.black.opacity(0.55)], startPoint: .center, endPoint: .bottom)
                .frame(height: 220)
                .clipShape(RoundedRectangle(cornerRadius: Radius.cover, style: .continuous))
        }
        .frame(maxWidth: .infinity)
        .padding(.top, 4)
    }

    private func titleBlock(_ song: Song) -> some View {
        VStack(spacing: 4) {
            Text(song.name)
                .font(.system(size: 20, weight: .bold))
                .foregroundColor(Palette.text)
                .lineLimit(1)
            Text("\(song.displaySinger) · \(song.displayAlbum)")
                .font(FType.sub())
                .foregroundColor(Palette.textSub)
                .lineLimit(1)
        }
        .padding(.top, 16)
    }

    @ViewBuilder
    private var lyricBlock: some View {
        VStack(spacing: 8) {
            if let lyric = player.lyric, !lyric.lines.isEmpty {
                let current = max(player.lyricIndex, 0)
                ForEach(visibleLines(lyric, current: current), id: \.id) { line in
                    let isCurrent = line.time == lyric.lines[min(current, lyric.lines.count - 1)].time
                    VStack(spacing: 2) {
                        Text(line.text.isEmpty ? "♪" : line.text)
                            .font(.system(size: isCurrent ? 16 : 13, weight: isCurrent ? .semibold : .regular))
                            .foregroundColor(isCurrent ? Palette.accent : Palette.textSub.opacity(0.75))
                            .lineLimit(1)
                        if let trans = line.trans, !trans.isEmpty {
                            Text(trans)
                                .font(.system(size: 11))
                                .foregroundColor(Palette.textSub.opacity(0.6))
                                .lineLimit(1)
                        }
                    }
                }
            } else {
                Text("暂无歌词")
                    .font(FType.chip())
                    .foregroundColor(Palette.textSub)
            }
        }
        .frame(maxWidth: .infinity)
        .frame(height: 132)
        .padding(.top, 10)
        .animation(.easeInOut(duration: 0.2), value: player.lyricIndex)
    }

    private func visibleLines(_ lyric: Lyric, current: Int) -> [LyricLine] {
        let start = max(0, current - 1)
        let end = min(lyric.lines.count, start + 5)
        return Array(lyric.lines[start..<end])
    }

    private var progressBlock: some View {
        VStack(spacing: 6) {
            GeometryReader { geo in
                let total = max(player.duration, 0.001)
                let value = dragging ?? player.progress
                let ratio = min(max(value / total, 0), 1)
                ZStack(alignment: .leading) {
                    Capsule().fill(Palette.trackBg)
                    Capsule()
                        .fill(Palette.progressGradient)
                        .frame(width: max(ratio * geo.size.width, 8))
                }
                .frame(height: 8)
                .contentShape(Rectangle())
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged { g in
                            dragging = min(max(g.location.x / geo.size.width, 0), 1) * total
                        }
                        .onEnded { _ in
                            if let target = dragging { player.seek(target) }
                            dragging = nil
                        }
                )
            }
            .frame(height: 8)

            HStack {
                Text(Fmt.duration(dragging ?? player.progress))
                    .font(FType.subSm())
                    .foregroundColor(Palette.textSub)
                Spacer()
                Text(Fmt.duration(player.duration))
                    .font(FType.subSm())
                    .foregroundColor(Palette.textSub)
            }
        }
        .padding(.top, 10)
    }

    private var controls: some View {
        HStack(spacing: 0) {
            Button {
                player.cycleMode()
            } label: {
                VectorIcon(icon: player.mode.icon, size: 22, color: Palette.textSub)
                    .frame(width: 52, height: 52)
            }
            .buttonStyle(.plain)

            Spacer(minLength: 0)

            Button {
                player.prev()
            } label: {
                VectorIcon(icon: .prev, size: 30, color: Palette.text)
                    .frame(width: 64, height: 64)
            }
            .buttonStyle(.plain)
            .accessibilityLabel("上一首")

            Button {
                player.toggle()
            } label: {
                ZStack {
                    Circle().fill(Palette.accent)
                    VectorIcon(icon: player.isPlaying ? .pause : .play, size: 34, color: Color(hex: 0x14161B))
                }
                .frame(width: 80, height: 80)
            }
            .buttonStyle(.plain)
            .padding(.horizontal, 22)
            .accessibilityLabel("播放暂停")

            Button {
                player.next()
            } label: {
                VectorIcon(icon: .next, size: 30, color: Palette.text)
                    .frame(width: 64, height: 64)
            }
            .buttonStyle(.plain)
            .accessibilityLabel("下一首")

            Spacer(minLength: 0)

            Button {
                showQuality = true
            } label: {
                VectorIcon(icon: .note, size: 22, color: Palette.textSub)
                    .frame(width: 52, height: 52)
            }
            .buttonStyle(.plain)
            .accessibilityLabel("音质")
        }
        .padding(.top, 8)
    }

    private func bottomRow(_ song: Song) -> some View {
        VStack(spacing: 12) {
            HStack(spacing: 10) {
                Text(store.settings.playQuality.display)
                    .font(FType.chip())
                    .foregroundColor(Palette.accent)
                    .padding(.horizontal, 12)
                    .frame(height: 30)
                    .background(Capsule().fill(Palette.accentFill))
                    .overlay(Capsule().stroke(Palette.accentStroke, lineWidth: 1))
                    .onTapGesture { showQuality = true }

                Spacer(minLength: 0)

                Button {
                    store.toggleFavorite(song)
                } label: {
                    VectorIcon(icon: .heart, size: 22,
                               color: store.isFavorite(song) ? Palette.accent : Palette.textSub)
                        .frame(width: 44, height: 44)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("收藏")

                Button {
                    Downloader.shared.download(song: song, quality: store.settings.downloadQuality, store: store)
                } label: {
                    VectorIcon(icon: .download, size: 22, color: Palette.textSub)
                        .frame(width: 44, height: 44)
                }
                .buttonStyle(.plain)
                .accessibilityLabel("下载")
            }

            HStack(spacing: 10) {
                VectorIcon(icon: .note, size: 16, color: Palette.textSub.opacity(0.7))
                Slider(value: Binding(get: { player.volume }, set: { player.setVolume($0) }), in: 0...1)
                    .tint(Palette.accent)
            }

            if let err = player.errorText {
                Text(err)
                    .font(FType.subSm())
                    .foregroundColor(Palette.danger)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .padding(.top, 12)
    }
}

/// 播放列表抽屉
struct QueueSheet: View {
    @EnvironmentObject private var store: AppStore
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("播放列表 · \(store.player.queue.count) 首")
                    .font(FType.sectionSm())
                    .foregroundColor(Palette.text)
                Spacer()
                Button("收起") { dismiss() }
                    .font(FType.chip())
                    .foregroundColor(Palette.textSub)
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 14)

            ScrollView(showsIndicators: false) {
                LazyVStack(spacing: 0) {
                    ForEach(Array(store.player.queue.enumerated()), id: \.element.id) { index, song in
                        let isCurrent = store.player.current?.id == song.id
                        SongRowView(song: song, index: index + 1, showQuality: false) {
                            store.playAll(store.player.queue, startAt: index)
                        } onMore: {
                            store.show("已加入队列")
                        }
                        .background(isCurrent ? Palette.surface : Color.clear)
                    }
                }
                .padding(.horizontal, 12)
                .padding(.bottom, 20)
            }
        }
        .background(Palette.sheet.ignoresSafeArea())
    }
}
