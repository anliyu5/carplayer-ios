﻿import Foundation

/// 对应 Android com.carplayer.repo.Downloader：下载到「文件 App → CarPlayer/Music」，
/// Android 侧是 手机存储/Music/Music，iOS 侧等价路径为 App 沙盒 Documents/Music。
@MainActor
final class Downloader: NSObject, ObservableObject {
    static let shared = Downloader()

    /// 任务标识映射（线程安全）
    final class Registry: @unchecked Sendable {
        private var map: [Int: String] = [:]
        private let lock = NSLock()
        func set(_ key: String, for id: Int) { lock.lock(); map[id] = key; lock.unlock() }
        func key(for id: Int) -> String { lock.lock(); defer { lock.unlock() }; return map[id] ?? "" }
    }

    struct Job: Identifiable {
        let song: Song
        var progress: Double
        var state: State
        var id: String { song.id + ":" + song.source.rawValue }
    }

    enum State: String {
        case waiting = "等待中"
        case running = "下载中"
        case done = "下载完成"
        case failed = "下载失败"
    }

    @Published private(set) var jobs: [Job] = []

    private var session: URLSession!
    /// taskIdentifier -> song key，delegate 回调在非主线程，故用锁保护
    nonisolated private let registry = Registry()

    private override init() {
        super.init()
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 30
        session = URLSession(configuration: config, delegate: self, delegateQueue: nil)
    }

    var musicDirectory: URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let dir = docs.appendingPathComponent("Music", isDirectory: true)
        try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
        return dir
    }

    func download(song: Song, quality: Quality, store: AppStore) {
        let key = song.id + ":" + song.source.rawValue
        guard !jobs.contains(where: { $0.id == key && $0.state != .failed }) else { return }
        jobs.append(Job(song: song, progress: 0, state: .waiting))
        let index = jobs.count - 1

        Task { @MainActor in
            do {
                let url = try await store.resolveURL(for: song, quality: quality)
                var request = URLRequest(url: url)
                request.setValue("Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X)", forHTTPHeaderField: "User-Agent")
                let dl = session.downloadTask(with: request)
                registry.set(key, for: dl.taskIdentifier)
                dl.resume()
                jobs[index].state = .running
            } catch {
                jobs[index].state = .failed
                store.show("下载失败：\(error.localizedDescription)")
            }
        }
    }

    func downloadAll(_ songs: [Song], quality: Quality, store: AppStore) {
        guard !songs.isEmpty else { store.show("没有可下载的歌曲"); return }
        for song in songs { download(song: song, quality: quality, store: store) }
        store.show("开始下载 \(songs.count) 首")
    }

    func remove(_ job: Job) {
        jobs.removeAll { $0.id == job.id }
    }

    func clearDone() {
        jobs.removeAll { $0.state == .done }
    }

    private func finish(key: String, location: URL, success: Bool) {
        guard let index = jobs.firstIndex(where: { $0.id == key }) else { return }
        guard success else {
            jobs[index].state = .failed
            return
        }
        let ext = location.pathExtension.isEmpty ? "mp3" : location.pathExtension.lowercased()
        let name = sanitize("\(jobs[index].song.displaySinger) - \(jobs[index].song.name)") + "." + ext
        let target = musicDirectory.appendingPathComponent(name)
        try? FileManager.default.removeItem(at: target)
        do {
            try FileManager.default.moveItem(at: location, to: target)
            jobs[index].state = .done
            jobs[index].progress = 1
        } catch {
            jobs[index].state = .failed
        }
    }

    private func sanitize(_ name: String) -> String {
        let invalid = CharacterSet(charactersIn: "/\\:*?\"<>|")
        return name.components(separatedBy: invalid).joined(separator: "_")
    }

    /// 扫描本地已下载音乐（对应 LocalMusic）
    func scanLocalSongs() -> [Song] {
        guard let files = try? FileManager.default.contentsOfDirectory(at: musicDirectory,
                                                                     includingPropertiesForKeys: nil) else { return [] }
        return files.compactMap { file in
            guard !file.hasDirectoryPath else { return nil }
            let base = file.deletingPathExtension().lastPathComponent
            let parts = base.components(separatedBy: " - ")
            let singer = parts.count > 1 ? parts[0] : "未知歌手"
            let name = parts.count > 1 ? parts[1] : base
            return Song(id: file.lastPathComponent, source: .local, name: name, singer: singer,
                        albumName: nil, picUrl: nil, interval: 0,
                        qualitys: [.k320], localPath: file.path)
        }
    }
}

extension Downloader: URLSessionDownloadDelegate {
    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                                didFinishDownloadingTo location: URL) {
        let key = registry.key(for: downloadTask.taskIdentifier)
        let ok = (downloadTask.response as? HTTPURLResponse).map { (200..<300).contains($0.statusCode) } ?? true
        let temp = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
        try? FileManager.default.copyItem(at: location, to: temp)
        Task { @MainActor in
            self.finish(key: key, location: temp, success: ok)
        }
    }

    nonisolated func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask,
                                didWriteData bytesWritten: Int64,
                                totalBytesWritten: Int64,
                                totalBytesExpectedToWrite: Int64) {
        guard totalBytesExpectedToWrite > 0 else { return }
        let ratio = Double(totalBytesWritten) / Double(totalBytesExpectedToWrite)
        let key = registry.key(for: downloadTask.taskIdentifier)
        Task { @MainActor in
            if let index = self.jobs.firstIndex(where: { $0.id == key }) {
                self.jobs[index].progress = ratio
            }
        }
    }

    nonisolated func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        guard error != nil else { return }
        let key = registry.key(for: task.taskIdentifier)
        Task { @MainActor in
            if let index = self.jobs.firstIndex(where: { $0.id == key }) {
                self.jobs[index].state = .failed
            }
        }
    }
}

